// DOM 요소 가져오기
const form = document.getElementById("rental-form");
const messageEl = document.getElementById("message");
const equipmentTypeSelect = document.getElementById("equipment-type");
const equipmentItemGroup = document.getElementById("equipment-item-group");
const equipmentItemSelect = document.getElementById("equipment-item");
const rentalStatusContent = document.getElementById("rental-status-content");
const returnToggleBtn = document.getElementById("return-toggle-btn");
const returnPanel = document.getElementById("return-panel");
const returnNameInput = document.getElementById("return-name");
const returnLookupBtn = document.getElementById("return-lookup-btn");
const returnResultsEl = document.getElementById("return-results");
const returnConfirmSection = document.getElementById("return-confirm-section");
const returnConfirmInput = document.getElementById("return-confirm-input");
const returnSubmitBtn = document.getElementById("return-submit-btn");
const returnMessageEl = document.getElementById("return-message");

// 현재 대여 현황 데이터 (구글 스프레드시트에서 가져온 값)
let currentRentals = [];
let currentReturnName = "";

// 장비 옵션 정의
const equipmentOptions = {
  scope: [
    { value: "스코프1", label: "스코프1" },
    { value: "스코프2", label: "스코프2" }
  ],
  tripod: [
    { value: "삼각대1", label: "삼각대1" },
    { value: "삼각대2", label: "삼각대2" }
  ],
  binoculars: [
    { value: "쌍안경1", label: "쌍안경1" },
    { value: "쌍안경2", label: "쌍안경2" }
  ]
};

// 날짜 선택기 초기화
function initDateSelectors() {
  const currentYear = new Date().getFullYear();
  const years = [];
  const months = [];
  const days = [];

  // 년도: 현재 년도부터 2년 후까지
  for (let i = currentYear; i <= currentYear + 2; i++) {
    years.push(i);
  }

  // 월: 1-12
  for (let i = 1; i <= 12; i++) {
    months.push(i);
  }

  // 일: 1-31 (실제로는 월에 따라 달라지지만 간단하게 31일까지)
  for (let i = 1; i <= 31; i++) {
    days.push(i);
  }

  // 년도 선택기 채우기
  const yearSelects = document.querySelectorAll("#rental-year, #return-year");
  yearSelects.forEach(select => {
    years.forEach(year => {
      const option = document.createElement("option");
      option.value = year;
      option.textContent = year + "년";
      select.appendChild(option);
    });
  });

  // 월 선택기 채우기
  const monthSelects = document.querySelectorAll("#rental-month, #return-month");
  monthSelects.forEach(select => {
    months.forEach(month => {
      const option = document.createElement("option");
      option.value = month;
      option.textContent = month + "월";
      select.appendChild(option);
    });
  });

  // 일 선택기 채우기
  const daySelects = document.querySelectorAll("#rental-day, #return-day");
  daySelects.forEach(select => {
    days.forEach(day => {
      const option = document.createElement("option");
      option.value = day;
      option.textContent = day + "일";
      select.appendChild(option);
    });
  });
}

// 기종 선택에 따라 장비 옵션 업데이트
equipmentTypeSelect.addEventListener("change", (e) => {
  const selectedType = e.target.value;
  
  if (selectedType && equipmentOptions[selectedType]) {
    equipmentItemGroup.style.display = "block";
    equipmentItemSelect.innerHTML = '<option value="">장비를 선택하세요</option>';
    
    equipmentOptions[selectedType].forEach(item => {
      const option = document.createElement("option");
      option.value = item.value;
      option.textContent = item.label;
      equipmentItemSelect.appendChild(option);
    });
    
    equipmentItemSelect.required = true;
  } else {
    equipmentItemGroup.style.display = "none";
    equipmentItemSelect.required = false;
    equipmentItemSelect.innerHTML = '<option value="">장비를 선택하세요</option>';
  }
});

// 폼 제출 처리
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  
  messageEl.textContent = "";
  messageEl.className = "message";

  // 폼 데이터 수집
  const name = document.getElementById("name").value.trim();
  const rentalYear = document.getElementById("rental-year").value;
  const rentalMonth = document.getElementById("rental-month").value;
  const rentalDay = document.getElementById("rental-day").value;
  const returnYear = document.getElementById("return-year").value;
  const returnMonth = document.getElementById("return-month").value;
  const returnDay = document.getElementById("return-day").value;
  const equipmentType = equipmentTypeSelect.value;
  const equipmentItem = equipmentItemSelect.value;

  // 유효성 검사
  if (!name || !rentalYear || !rentalMonth || !rentalDay || 
      !returnYear || !returnMonth || !returnDay || !equipmentType || !equipmentItem) {
    showMessage("모든 항목을 입력해주세요.", "error");
    return;
  }

  // 날짜 유효성 검사
  const rentalDate = new Date(rentalYear, rentalMonth - 1, rentalDay);
  const returnDate = new Date(returnYear, returnMonth - 1, returnDay);
  
  if (returnDate < rentalDate) {
    showMessage("반납 일자는 대여 일자보다 늦어야 합니다.", "error");
    return;
  }

  // 이미 대여 중인 장비와 기간이 겹치는지 확인
  if (isOverlappingReservation(equipmentItem, rentalDate, returnDate)) {
    showMessage("이미 해당 기간에 대여 중인 장비입니다. 다른 기간을 선택해주세요.", "error");
    return;
  }

  // 데이터 포맷팅
  const rentalDateStr = `${rentalYear}-${String(rentalMonth).padStart(2, '0')}-${String(rentalDay).padStart(2, '0')}`;
  const returnDateStr = `${returnYear}-${String(returnMonth).padStart(2, '0')}-${String(returnDay).padStart(2, '0')}`;

  const formData = {
    name: name,
    rentalDate: rentalDateStr,
    returnDate: returnDateStr,
    equipmentType: equipmentType,
    equipmentItem: equipmentItem
  };

  try {
    showMessage("처리 중...", "info");
    
    const res = await fetch("/api/rental", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(formData)
    });

    const rawText = await res.text();
    let data = null;
    try {
      data = JSON.parse(rawText);
    } catch {
      data = null;
    }

    if (!res.ok) {
      // Apache/프록시 에러 페이지(HTML) 등 JSON이 아닐 수 있음
      const fallback =
        rawText && rawText.trim().startsWith("<")
          ? "서버가 JSON 대신 HTML을 응답했습니다. (백엔드/프록시 상태를 확인하세요.)"
          : "대여 신청에 실패했습니다.";
      throw new Error((data && data.message) || fallback);
    }

    showMessage("장비 대여 신청이 완료되었습니다!", "success");
    form.reset();
    equipmentItemGroup.style.display = "none";
    equipmentItemSelect.innerHTML = '<option value="">장비를 선택하세요</option>';
    // 대여 현황 다시 불러오기
    loadRentalStatus();
    
  } catch (err) {
    console.error(err);
    showMessage(err.message || "알 수 없는 오류가 발생했습니다.", "error");
  }
});

// 메시지 표시 함수
function showMessage(text, type = "info") {
  messageEl.textContent = text;
  messageEl.className = `message message--${type}`;
  
  if (type === "success") {
    setTimeout(() => {
      messageEl.textContent = "";
      messageEl.className = "message";
    }, 5000);
  }
}

// 장비 대여 현황 불러오기
async function loadRentalStatus() {
  if (!rentalStatusContent) return;

  rentalStatusContent.innerHTML = '<p class="rental-status__empty">대여 현황을 불러오는 중입니다...</p>';

  try {
    const res = await fetch("/api/rentals");
    const rawText = await res.text();
    let data = null;
    try {
      data = JSON.parse(rawText);
    } catch {
      data = null;
    }

    if (!res.ok || !data || !data.ok) {
      throw new Error(
        (data && data.message) || "대여 현황을 불러오는 데 실패했습니다."
      );
    }

    const rows = Array.isArray(data.rows) ? data.rows : [];
    currentRentals = rows;
    renderRentalStatus(rows);
  } catch (error) {
    console.error(error);
    rentalStatusContent.innerHTML =
      '<p class="rental-status__empty">대여 현황을 불러오지 못했습니다. 잠시 후 다시 시도해주세요.</p>';
  }
}

// 장비 대여 현황 렌더링
function renderRentalStatus(rows) {
  if (!rentalStatusContent) return;

  if (!rows || rows.length === 0) {
    rentalStatusContent.innerHTML =
      '<p class="rental-status__empty">현재 등록된 대여가 없습니다.</p>';
    return;
  }

  const now = new Date();

  const rowsHtml = rows
    .map((r) => {
      const start = new Date(r.rentalDate);
      const end = new Date(r.returnDate);

      let statusClass = "rental-status__badge--future";
      let statusLabel = "대여 예정";

      if (!isNaN(start) && !isNaN(end)) {
        if (now > end) {
          statusClass = "rental-status__badge--past";
          statusLabel = "대여 완료";
        } else if (now >= start && now <= end) {
          statusClass = "rental-status__badge--ongoing";
          statusLabel = "대여 중";
        }
      }

      const rentalRange = `${formatDateOnly(start, r.rentalDate)} ~ ${formatDateOnly(
        end,
        r.returnDate
      )}`;

      return `
        <tr>
          <td>${r.equipmentItem || "-"}</td>
          <td>${r.equipmentType || "-"}</td>
          <td>${r.name || "-"}</td>
          <td>${rentalRange}</td>
          <td>
            <span class="rental-status__badge ${statusClass}">
              ${statusLabel}
            </span>
          </td>
        </tr>
      `;
    })
    .join("");

  rentalStatusContent.innerHTML = `
    <table class="rental-status__list">
      <thead>
        <tr>
          <th>장비</th>
          <th>기종</th>
          <th>대여자</th>
          <th>대여 기간</th>
          <th>상태</th>
        </tr>
      </thead>
      <tbody>
        ${rowsHtml}
      </tbody>
    </table>
  `;
}

// 기간 겹침 여부 확인
function isOverlappingReservation(equipmentItem, startDate, endDate) {
  if (!equipmentItem || !currentRentals || currentRentals.length === 0) {
    return false;
  }

  return currentRentals.some((r) => {
    if (r.equipmentItem !== equipmentItem) return false;

    const existingStart = new Date(r.rentalDate);
    const existingEnd = new Date(r.returnDate);

    if (isNaN(existingStart) || isNaN(existingEnd)) return false;

    // 기간이 하나라도 겹치면 true
    return startDate <= existingEnd && endDate >= existingStart;
  });
}

// 날짜를 MM-DD 형식으로만 보여주기
function formatDateOnly(dateObj, fallback) {
  if (dateObj instanceof Date && !isNaN(dateObj)) {
    const m = String(dateObj.getMonth() + 1).padStart(2, "0");
    const d = String(dateObj.getDate()).padStart(2, "0");
    return `${m}-${d}`;
  }
  // dateObj가 유효하지 않으면, 이미 문자열 형태(예: "2026-02-17T...")에서 월-일 부분만 사용
  if (typeof fallback === "string" && fallback.length >= 10) {
    // "YYYY-MM-DD..." → "MM-DD"
    return fallback.slice(5, 10);
  }
  return fallback || "-";
}

// 장비 반납 패널 토글 및 동작
if (returnToggleBtn && returnPanel) {
  returnToggleBtn.addEventListener("click", () => {
    const isHidden = returnPanel.classList.contains("hidden");
    if (isHidden) {
      returnPanel.classList.remove("hidden");
    } else {
      returnPanel.classList.add("hidden");
    }
  });
}

// 이름으로 대여 내역 조회
if (returnLookupBtn) {
  returnLookupBtn.addEventListener("click", async () => {
    const name = (returnNameInput?.value || "").trim();
    returnMessageEl.textContent = "";
    returnConfirmInput.value = "";
    returnConfirmSection.classList.add("hidden");
    returnResultsEl.innerHTML = "";

    if (!name) {
      returnMessageEl.textContent = "이름을 입력해주세요.";
      returnMessageEl.className = "message message--error";
      return;
    }

    try {
      returnMessageEl.textContent = "대여 내역을 불러오는 중입니다...";
      returnMessageEl.className = "message message--info";

      const res = await fetch("/api/returns/preview", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ name })
      });

      const rawText = await res.text();
      let data = null;
      try {
        data = JSON.parse(rawText);
      } catch {
        data = null;
      }

      if (!res.ok || !data || !data.ok) {
        throw new Error(
          (data && data.message) || "대여 내역을 불러오는 데 실패했습니다."
        );
      }

      const rows = Array.isArray(data.rows) ? data.rows : [];

      if (rows.length === 0) {
        returnResultsEl.innerHTML =
          '<p class="rental-status__empty">해당 이름으로 등록된 대여가 없습니다.</p>';
        returnMessageEl.textContent = "";
        returnMessageEl.className = "message";
        return;
      }

      currentReturnName = name;

      const rowsHtml = rows
        .map((r) => {
          const start = new Date(r.rentalDate);
          const end = new Date(r.returnDate);
          const rentalRange = `${formatDateOnly(start, r.rentalDate)} ~ ${formatDateOnly(
            end,
            r.returnDate
          )}`;

          return `
            <tr>
              <td>${r.equipmentItem || "-"}</td>
              <td>${r.equipmentType || "-"}</td>
              <td>${r.name || "-"}</td>
              <td>${rentalRange}</td>
            </tr>
          `;
        })
        .join("");

      returnResultsEl.innerHTML = `
        <div class="return-results__table-wrapper">
          <table>
            <thead>
              <tr>
                <th>장비</th>
                <th>기종</th>
                <th>대여자</th>
                <th>대여 기간</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
            </tbody>
          </table>
        </div>
      `;

      returnConfirmSection.classList.remove("hidden");
      returnMessageEl.textContent = "";
      returnMessageEl.className = "message";
    } catch (error) {
      console.error(error);
      returnMessageEl.textContent =
        error.message || "대여 내역을 불러오는 중 오류가 발생했습니다.";
      returnMessageEl.className = "message message--error";
    }
  });
}

// 반납 확정 처리
if (returnSubmitBtn) {
  returnSubmitBtn.addEventListener("click", async () => {
    const name = currentReturnName.trim();
    const confirmText = (returnConfirmInput?.value || "").trim();

    if (!name) {
      returnMessageEl.textContent = "먼저 이름으로 대여 내역을 조회해주세요.";
      returnMessageEl.className = "message message--error";
      return;
    }

    if (confirmText !== "확인했습니다") {
      returnMessageEl.textContent =
        '하단 칸에 정확히 "확인했습니다"라고 입력해야 반납할 수 있습니다.';
      returnMessageEl.className = "message message--error";
      return;
    }

    try {
      returnMessageEl.textContent = "반납을 처리하는 중입니다...";
      returnMessageEl.className = "message message--info";

      const res = await fetch("/api/returns/confirm", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ name, confirmationText: confirmText })
      });

      const rawText = await res.text();
      let data = null;
      try {
        data = JSON.parse(rawText);
      } catch {
        data = null;
      }

      if (!res.ok || !data || !data.ok) {
        throw new Error(
          (data && data.message) || "반납 처리에 실패했습니다. 잠시 후 다시 시도해주세요."
        );
      }

      returnMessageEl.textContent = "반납이 완료되었습니다.";
      returnMessageEl.className = "message message--success";
      returnResultsEl.innerHTML = "";
      returnConfirmInput.value = "";
      currentReturnName = "";

      // 대여 현황 갱신
      loadRentalStatus();
    } catch (error) {
      console.error(error);
      returnMessageEl.textContent =
        error.message || "반납 처리 중 오류가 발생했습니다.";
      returnMessageEl.className = "message message--error";
    }
  });
}

// 페이지 로드 시 날짜 선택기 초기화 및 대여 현황 불러오기
initDateSelectors();
loadRentalStatus();
