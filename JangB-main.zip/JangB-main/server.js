const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("src")); // 정적 파일 (index.html, script.js, style.css)

// 구글 스프레드시트 Web App URL (환경변수 또는 직접 설정)
// 이 URL은 Google Apps Script에서 생성됩니다 (설정 가이드 참조)
const GOOGLE_SCRIPT_URL =
  process.env.GOOGLE_SCRIPT_URL ||
  "https://script.google.com/macros/s/AKfycby8DVwrYb17HasHSN8Xc6GM4XdOJgvYefoS--Ipfvo4XOvugrFyTmwEFiZd7eImCBw/exec";

// 상태 확인 (Apache 프록시/Node 연결 확인용)
app.get("/api/health", (req, res) => {
  return res.json({
    ok: true,
    service: "equipment-rental",
    time: new Date().toISOString()
  });
});

// 현재 대여 현황 조회 API (구글 스프레드시트 → 읽기)
app.get("/api/rentals", async (req, res) => {
  if (!GOOGLE_SCRIPT_URL) {
    return res.status(500).json({
      ok: false,
      message:
        "구글 스프레드시트 Web App URL이 설정되지 않았습니다. GOOGLE_SCRIPT_URL 환경변수 또는 server.js를 확인해주세요."
    });
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12_000);

    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: "GET",
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    const contentType = response.headers.get("content-type") || "";
    const bodyText = await response.text();
    const bodyPreview = bodyText.slice(0, 700);

    console.log("[GoogleScript][LIST] status:", response.status, response.statusText);
    console.log("[GoogleScript][LIST] content-type:", contentType);
    console.log("[GoogleScript][LIST] body preview:", bodyPreview);

    if (!response.ok) {
      return res.status(502).json({
        ok: false,
        message: `구글 스프레드시트(Web App) 목록 조회 오류: ${response.status} ${response.statusText}`,
        details: { contentType, bodyPreview }
      });
    }

    let result = null;
    try {
      result = JSON.parse(bodyText);
    } catch {
      result = null;
    }

    if (!result || (!Array.isArray(result.rows) && !Array.isArray(result.data))) {
      return res.status(502).json({
        ok: false,
        message:
          "구글 스프레드시트(Web App) 응답 형식이 올바르지 않습니다. doGet에서 rows(또는 data) 배열을 JSON으로 반환하도록 수정해주세요.",
        details: { contentType, bodyPreview }
      });
    }

    const rows = Array.isArray(result.rows) ? result.rows : result.data;

    return res.json({
      ok: true,
      rows
    });
  } catch (error) {
    console.error("구글 스프레드시트 대여 목록 조회 오류:", error);
    return res.status(500).json({
      ok: false,
      message: "대여 현황을 불러오는 중 오류가 발생했습니다.",
      details: {
        error: error?.message || String(error)
      }
    });
  }
});

// 장비 대여 신청 API
app.post("/api/rental", async (req, res) => {
  const { name, rentalDate, returnDate, equipmentType, equipmentItem } = req.body;

  // 유효성 검사
  if (!name || !rentalDate || !returnDate || !equipmentType || !equipmentItem) {
    return res.status(400).json({
      ok: false,
      message: "모든 항목을 입력해주세요."
    });
  }

  // 구글 스프레드시트 URL이 설정되지 않은 경우
  if (!GOOGLE_SCRIPT_URL) {
    console.log("대여 신청 데이터:", {
      name,
      rentalDate,
      returnDate,
      equipmentType,
      equipmentItem,
      timestamp: new Date().toISOString()
    });
    
    return res.json({
      ok: true,
      message: "대여 신청이 완료되었습니다. (구글 스프레드시트 연동 전 - 콘솔에 로그 출력)",
      data: { name, rentalDate, returnDate, equipmentType, equipmentItem }
    });
  }

  // 구글 스프레드시트로 데이터 전송  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12_000);

    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      signal: controller.signal,
      body: JSON.stringify({
        name,
        rentalDate,
        returnDate,
        equipmentType,
        equipmentItem,
        timestamp: new Date().toISOString()
      })
    });

    clearTimeout(timeoutId);

    const contentType = response.headers.get("content-type") || "";
    const bodyText = await response.text();
    const bodyPreview = bodyText.slice(0, 700);

    console.log("[GoogleScript] status:", response.status, response.statusText);
    console.log("[GoogleScript] content-type:", contentType);
    console.log("[GoogleScript] body preview:", bodyPreview);

    if (!response.ok) {
      return res.status(502).json({
        ok: false,
        message: `구글 스프레드시트(Web App) 응답 오류: ${response.status} ${response.statusText}`,
        details: { contentType, bodyPreview }
      });
    }

    let result = null;
    try {
      result = JSON.parse(bodyText);
    } catch {
      result = null;
    }

    if (!result) {
      // 보통 배포 권한이 제한되어 있으면 HTML 로그인/권한 페이지가 내려옵니다.
      return res.status(502).json({
        ok: false,
        message:
          "구글 스프레드시트(Web App) 응답이 JSON이 아닙니다. Apps Script 배포 설정(액세스: 모든 사용자)과 URL을 확인하세요.",
        details: { contentType, bodyPreview }
      });
    }

    // Apps Script에서 success: false로 내려온 경우 (예: 기간 겹침 등 비즈니스 오류)
    if (result && result.success === false) {
      return res.status(409).json({
        ok: false,
        message:
          result.message ||
          "대여 신청 처리 중 오류가 발생했습니다. (구글 스프레드시트 Web App 응답)",
        details: result.error ? { error: result.error } : undefined
      });
    }

    return res.json({
      ok: true,
      message: "장비 대여 신청이 완료되었습니다.",
      data: result
    });

  } catch (error) {
    console.error("구글 스프레드시트 연동 오류:", error);
    return res.status(500).json({
      ok: false,
      message: "데이터 저장 중 오류가 발생했습니다.",
      details: {
        error: error?.message || String(error),
        hint:
          "서버 콘솔 로그의 [GoogleScript] 내용을 확인하세요. (권한/URL/리다이렉트/네트워크 문제일 수 있습니다.)"
      }
    });
  }
});

// 장비 반납 – 이름으로 대여 내역 조회
app.post("/api/returns/preview", async (req, res) => {
  const { name } = req.body || {};

  if (!name || typeof name !== "string" || !name.trim()) {
    return res.status(400).json({
      ok: false,
      message: "이름을 입력해주세요."
    });
  }

  if (!GOOGLE_SCRIPT_URL) {
    return res.status(500).json({
      ok: false,
      message:
        "구글 스프레드시트 Web App URL이 설정되지 않았습니다. GOOGLE_SCRIPT_URL 환경변수 또는 server.js를 확인해주세요."
    });
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12_000);

    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      signal: controller.signal,
      body: JSON.stringify({
        action: "previewReturn",
        name: name.trim()
      })
    });

    clearTimeout(timeoutId);

    const contentType = response.headers.get("content-type") || "";
    const bodyText = await response.text();
    const bodyPreview = bodyText.slice(0, 700);

    console.log("[GoogleScript][RETURN_PREVIEW] status:", response.status, response.statusText);
    console.log("[GoogleScript][RETURN_PREVIEW] content-type:", contentType);
    console.log("[GoogleScript][RETURN_PREVIEW] body preview:", bodyPreview);

    if (!response.ok) {
      return res.status(502).json({
        ok: false,
        message: `구글 스프레드시트(Web App) 반납 조회 오류: ${response.status} ${response.statusText}`,
        details: { contentType, bodyPreview }
      });
    }

    let result = null;
    try {
      result = JSON.parse(bodyText);
    } catch {
      result = null;
    }

    if (!result) {
      return res.status(502).json({
        ok: false,
        message: "구글 스프레드시트(Web App) 응답이 JSON이 아닙니다.",
        details: { contentType, bodyPreview }
      });
    }

    if (result.success === false) {
      return res.status(409).json({
        ok: false,
        message: result.message || "반납 조회 처리 중 오류가 발생했습니다.",
        details: result.error ? { error: result.error } : undefined
      });
    }

    const rows = Array.isArray(result.rows) ? result.rows : result.data || [];

    return res.json({
      ok: true,
      rows
    });
  } catch (error) {
    console.error("구글 스프레드시트 반납 조회 오류:", error);
    return res.status(500).json({
      ok: false,
      message: "반납 조회 중 오류가 발생했습니다.",
      details: {
        error: error?.message || String(error)
      }
    });
  }
});

// 장비 반납 – 실제 삭제 수행
app.post("/api/returns/confirm", async (req, res) => {
  const { name, confirmationText } = req.body || {};

  if (!name || typeof name !== "string" || !name.trim()) {
    return res.status(400).json({
      ok: false,
      message: "이름이 올바르지 않습니다."
    });
  }

  if (confirmationText !== "확인했습니다") {
    return res.status(400).json({
      ok: false,
      message: '하단 칸에 정확히 "확인했습니다"라고 입력해야 반납할 수 있습니다.'
    });
  }

  if (!GOOGLE_SCRIPT_URL) {
    return res.status(500).json({
      ok: false,
      message:
        "구글 스프레드시트 Web App URL이 설정되지 않았습니다. GOOGLE_SCRIPT_URL 환경변수 또는 server.js를 확인해주세요."
    });
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12_000);

    const response = await fetch(GOOGLE_SCRIPT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      signal: controller.signal,
      body: JSON.stringify({
        action: "confirmReturn",
        name: name.trim()
      })
    });

    clearTimeout(timeoutId);

    const contentType = response.headers.get("content-type") || "";
    const bodyText = await response.text();
    const bodyPreview = bodyText.slice(0, 700);

    console.log("[GoogleScript][RETURN_CONFIRM] status:", response.status, response.statusText);
    console.log("[GoogleScript][RETURN_CONFIRM] content-type:", contentType);
    console.log("[GoogleScript][RETURN_CONFIRM] body preview:", bodyPreview);

    if (!response.ok) {
      return res.status(502).json({
        ok: false,
        message: `구글 스프레드시트(Web App) 반납 처리 오류: ${response.status} ${response.statusText}`,
        details: { contentType, bodyPreview }
      });
    }

    let result = null;
    try {
      result = JSON.parse(bodyText);
    } catch {
      result = null;
    }

    if (!result) {
      return res.status(502).json({
        ok: false,
        message: "구글 스프레드시트(Web App) 응답이 JSON이 아닙니다.",
        details: { contentType, bodyPreview }
      });
    }

    if (result.success === false) {
      return res.status(409).json({
        ok: false,
        message: result.message || "반납 처리 중 오류가 발생했습니다.",
        details: result.error ? { error: result.error } : undefined
      });
    }

    return res.json({
      ok: true,
      deletedCount: result.deletedCount ?? null
    });
  } catch (error) {
    console.error("구글 스프레드시트 반납 처리 오류:", error);
    return res.status(500).json({
      ok: false,
      message: "반납 처리 중 오류가 발생했습니다.",
      details: {
        error: error?.message || String(error)
      }
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  if (!GOOGLE_SCRIPT_URL) {
    console.log("⚠️  구글 스프레드시트 URL이 설정되지 않았습니다.");
    console.log("   환경변수 GOOGLE_SCRIPT_URL을 설정하거나 server.js를 수정하세요.");
  }
});
